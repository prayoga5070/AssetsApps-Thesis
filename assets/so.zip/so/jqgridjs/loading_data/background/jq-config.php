<?php
// ** MySQL settings ** //
//define('DB_NAME', 'northwind');    // The name of the database
//define('DB_HOST', 'localhost');    // 99% chance you won't need to change this value
define('DB_DSN','mysql:host=localhost;dbname=guriddon_northwind');
define('DB_DSN1','mysql:host=localhost;dbname=guriddon_misim');
define('DB_USER', 'guriddon_tony');     // Your MySQL username
define('DB_PASSWORD', 'guri123ddo'); // ...and password
define('DB_DATABASE', 'guriddon_northwind'); // ...and password

define('ABSPATH', '../../../');
// Form settings
$SERVER_HOST = "";        // the host name
$SELF_PATH = "";    // the web path to the project without http
$CODE_PATH = "../../../../php/PHPSuito/"; // the physical path to the php files
